const express = require('express');
const multer = require('multer');
const faceapi = require('face-api.js');
const canvas = require('canvas');
const path = require('path');
const fs = require('fs');

const app = express();
const port = 3000;

// Configure multer for image uploads
const upload = multer({ dest: 'uploads/' });

// Monkey-patch canvas for face-api.js
const { Canvas, Image, ImageData } = canvas;
faceapi.env.monkeyPatch({ Canvas, Image, ImageData });

// Load face-api.js models
const loadModels = async () => {
  try {
    const modelPath = path.join(__dirname, 'models');
    console.log(`📂 Loading models from: ${modelPath}`);

    await faceapi.nets.ssdMobilenetv1.loadFromDisk(modelPath);
    console.log('✅ ssdMobilenetv1 model loaded');

    await faceapi.nets.faceLandmark68Net.loadFromDisk(modelPath);
    console.log('✅ faceLandmark68Net model loaded');

    await faceapi.nets.faceRecognitionNet.loadFromDisk(modelPath);
    console.log('✅ faceRecognitionNet model loaded');

    console.log('✅ All face models loaded successfully');
  } catch (error) {
    console.error('❌ Error loading models:', error);
    process.exit(1);
  }
};

loadModels();

let storedEmbedding = null;

// Extract face embeddings from an image
const getEmbeddings = async (imagePath) => {
  try {
    console.log(`📸 Processing image: ${imagePath}`);

    const img = await canvas.loadImage(imagePath);
    console.log('✅ Image loaded successfully');

    const detection = await faceapi.detectSingleFace(img).withFaceLandmarks().withFaceDescriptor();

    if (!detection) {
      console.warn('⚠️ No face detected');
      return null;
    }

    console.log('✅ Face detected, embedding extracted');
    console.log('Embedding:', JSON.stringify([...detection.descriptor]));

    return detection.descriptor;
  } catch (error) {
    console.error('❌ Error extracting embeddings:', error);
    return null;
  }
};

// Calculate Cosine similarity between two embeddings
const cosineSimilarity = (a, b) => {
  const dotProduct = a.reduce((sum, val, i) => sum + val * b[i], 0);
  const magnitudeA = Math.sqrt(a.reduce((sum, val) => sum + val * val, 0));
  const magnitudeB = Math.sqrt(b.reduce((sum, val) => sum + val * val, 0));

  const similarity = dotProduct / (magnitudeA * magnitudeB);
  console.log(`📏 Calculated Cosine Similarity: ${similarity}`);
  return similarity;
};

// Store face embedding endpoint
app.post('/api/store-face', upload.single('image'), async (req, res) => {
  console.log('📤 /api/store-face endpoint hit');

  if (!req.file) {
    console.warn('⚠️ No image provided');
    return res.status(400).json({ message: 'No image provided' });
  }

  try {
    const embedding = await getEmbeddings(req.file.path);
    fs.unlinkSync(req.file.path); // Clean up

    if (!embedding) {
      console.warn('⚠️ No face detected in provided image');
      return res.status(400).json({ message: 'No face detected' });
    }

    storedEmbedding = embedding;
    console.log('✅ Face embedding stored successfully');

    res.status(200).json({ message: '✅ Face embedding stored successfully' });
  } catch (error) {
    console.error('❌ Error storing face:', error);
    res.status(500).json({ message: 'Internal Server Error' });
  }
});

// Compare face endpoint
app.post('/api/compare-face', upload.single('image'), async (req, res) => {
  console.log('📤 /api/compare-face endpoint hit');

  if (!req.file) {
    console.warn('⚠️ No image provided');
    return res.status(400).json({ message: 'No image provided' });
  }

  if (!storedEmbedding) {
    console.warn('⚠️ No stored face embedding to compare');
    return res.status(400).json({ message: 'No stored face to compare' });
  }

  try {
    const newEmbedding = await getEmbeddings(req.file.path);
    fs.unlinkSync(req.file.path); // Clean up

    if (!newEmbedding) {
      console.warn('⚠️ No face detected in provided image');
      return res.status(400).json({ message: 'No face detected' });
    }

    const similarity = cosineSimilarity(storedEmbedding, newEmbedding);
    const isMatch = similarity > 0.8; // Threshold for matching (1 = identical, -1 = opposite)

    console.log(`🔍 Comparison result: ${isMatch ? 'Match' : 'No Match'} (Similarity: ${similarity.toFixed(4)})`);

    res.status(200).json({
      message: isMatch ? '✅ Face Match!' : '❌ Face Not Match!',
      similarity: similarity.toFixed(4),
    });
  } catch (error) {
    console.error('❌ Error comparing face:', error);
    res.status(500).json({ message: 'Internal Server Error' });
  }
});

// Start server
app.listen(port, () => console.log(`🚀 Server running on http://localhost:${port}`));
